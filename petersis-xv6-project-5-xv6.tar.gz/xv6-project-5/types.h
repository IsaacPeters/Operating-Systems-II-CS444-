#ifndef __TYPES_H
# define __TYPES_H

typedef unsigned long  ulong;

typedef unsigned int   uint;
typedef unsigned short ushort;
typedef unsigned char  uchar;
typedef uint pde_t;

#endif // __TYPES_H
