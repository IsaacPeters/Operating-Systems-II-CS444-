// Pseudo-random number generator
#ifndef MAX_RAND
    #define MAX_RAND (1<<31)
#endif

int rand(void);
void srand(unsigned);